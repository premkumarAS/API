from django.shortcuts import render
import requests
# Create your views here.
def index(request):
    key="2f3a93a4d730af3af823c959c1fb730a"
    URL='https://api.openweathermap.org/data/2.5/weather'
    if "city" in request.POST:
        city=request.POST['city']
    else: city="india"
    PARAMS={'q':city,'appid':key,'units':'metric'}
    r=requests.get(url=URL,params=PARAMS)
    RES=r.json()
    Description=RES['weather'][0]['description']
    
    Icon=RES['weather'][0]['icon']
    Temp=RES['main']['temp']
    Mtemp=RES['main']['temp_max']
    speed=RES['wind']['speed']
    night="haze","smoke","Haze"
    sun='clear sky',"sunny"
    snow='snow',"cold","ice",'light snow','overcast clouds'
    rain='broken clouds','moderate rain',"rain","light rain"
    clear='scattered clouds','cloudy','few clouds'
    return render(request,'index.html',{'RES':RES,'Description':Description,'Icon':Icon,'Temp':Temp,'sun':sun,"rain":rain,'clear':clear,"snow":snow,"night":night,"speed":speed,"mtemp":Mtemp,"city":city})
